/******************************************************************************

	PIC16F84 as an LED Controller
	-----------------------------
	Copyright 2004 by John Speth

	8 bit data bytes are transmitted serial synchronous.  There are two
	interface types available: a two wire and a one wire interface.  The CPU
	must run at 10MHz.

	The two wire interface has seperate clock and data lines.  Data (RB2 -
	pin 8) is valid on the rising edge of the clock (RB0 - 6).  Data is sent
	MSB to LSB order.  If reset (RB1 - pin 7) is low on a rising clock edge,
	the interface is reset.  At least 15usec must separate the clock rising
	edges.

	The one wire interface has a single clock/data line.  Data is encoded
	into the pulse width of the clock (RB0 - pin 6).  Long pulses (5usec)
	are 1's and short pulses (2usec) are 0's.  A very long pulse (15usec or
	longer) is an interface reset signal.  At least 15usec must separate the
	pulse rising edges.  Data is sent MSB to LSB order.  RB0 (pin 6) is the
	clock/data input.

	LEDs are connected to RA0-3 and RB4-7.  LED connections follow:
		LED7 - RB7 - pin 13
		LED6 - RB6 - pin 12
		LED5 - RB5 - pin 11
		LED4 - RB4 - pin 10
		LED3 - RA3 - pin 2
		LED2 - RA2 - pin 1
		LED1 - RA1 - pin 18
		LED0 - RA0 - pin 17

	MCLRn is used to hard reset the device.

	Demo board connections:
		Test point row:
			1 - GND
			2 - +5V
			3 - LED clock (input)
			4 - LED data (input)
			5 - scanner clock (input)
			6 - scanner data (output)
			7 - MCLRn (input)
			8 - RESETn (input)

		2x5 connector pins:
			1 - GND
			2 - GND
			3 - +5V
			4 - +5V
			5 - LED clock (input)
			6 - LED data (input)
			7 - scanner clock (input)
			8 - scanner data (output)
			9 - MCLRn (input)
			10 - RESETn (input)

		DIP16:
			1  - LED clock (input)
			2  - LED data (input)
			3  - scanner clock (input)
			4  - scanner data (output)
			5  - NC
			6  - NC
			7  - MCLRn (input)
			8  - RESETn (input)
			9  - GND
			10 - GND
			11 - GND
			12 - GND
			13 - +5V
			14 - +5V
			15 - +5V
			16 - +5V

	Each byte holds three items:
	  B[7-6]: Address
	  B[5-3]: Opcode
	  B[2-0]: Data

	Each controller has a device address to which it uniquely responds.
	There may be up to four unique addresses in a bussed system.

	The opcode is the instruction that the controller executes:
   	  0 = Exclusive bright on, data is the LED index (0 to 7)
   	  1 = Exclusive dim on, data is the LED index (0 to 7)
   	  2 = Exclusive blink, data is the LED index (0 to 7)
   	  3 = All, all off (data is zero) or all on (data is non-zero)
   	  4 = Single steady off, data is the LED index (0 to 7)
   	  5 = Single steady on, data is the LED index (0 to 7)
   	  6 = Blink rate, data is the blink rate (0 to 7)
   	  7 = Test mode, test is off (data is zero) or test on (data is non-zero)

	The CPU is clocked at Fosc=10MHz.  The instruction clock, Iclk is Fosc/4.
	The timer is clocked at Iclk/prescaler.  The prescaler is 8.  Therefore,
	the timer clock period is 3.2usec.  The timer rolls over at 625usec
	intervals if TMR0 is -195.

	An LED has a voltage drop of 1.5V.  The power supply is 5V.  The current
	limiting resistor should be 180 ohms for a current of 20ma.

******************************************************************************/

#include <16f84.h>
#include <int16cxx.h>

// CPU hardware configuration
#pragma	config |= 0x3FFF
#pragma	config FOSC=HS, WDTE=off, PWRTE=on

// Booleans
#define	TRUE				1
#define	FALSE				0

// TMR0 value to achieve a 10msec rollover
#define	TIMER_RATE			-195

// Data byte masks
#define	TARGET_MASK			0xC0
#define	OPCODE_MASK			0x38
#define	DATA_MASK			0x07

// These are the device address (one of 0x00 or 0x40 or 0x80 or 0xC0)
#define	TARGET_ADDRESS0		0x00
#define	TARGET_ADDRESS1		0x40
#define	TARGET_ADDRESS2		0x80
#define	TARGET_ADDRESS3		0xC0

// Opcodes
#define	OP_EXCLUSIVE_BRIGHT	0
#define	OP_EXCLUSIVE_DIM	1
#define	OP_EXCLUSIVE_BLINK	2
#define	OP_ALL				3
#define	OP_ON				4
#define	OP_OFF				5
#define	OP_RATE				6
#define	OP_TEST				7

// Native data definitions
typedef unsigned char byte;
typedef unsigned long word;

// Port bit definitions
#pragma bit ADDRESS_BIT		@ PORTB.3
#pragma bit DATAIN_BIT		@ PORTB.2
#pragma bit RESET_BIT		@ PORTB.1
#pragma bit CLOCKIN_BIT		@ PORTB.0

#ifdef TWO_WIRE_INTERFACE
	#define	DATA_CARRIER	DATAIN_BIT
#else
	#define	DATA_CARRIER	CLOCK_BIT
#endif

// Working variables for data byte reception
byte gDataMask;
byte gLocalDataByte;
byte gDataByte;
bit gDataByteReady;

// Testing flag and shift mask
byte gTest;

// The bright mask for all LEDs (1=bright, 0=off)
byte gBrightMask;

// The dim mask for all LEDs (1=dim, 0=off)
byte gDimMask;
byte gLocalDimMask;

// The blink mask for all LEDs (1=blinking, 0=off)
byte gBlinkMask;

// The blink interval (rate = (gBlinkInterval + 1) * 100msec)
word gBlinkInterval;

// The timer hit count
word gTimerHits;

///////////////////////////////////////////////////////////////////////////////
//
// Interrupt handler
//
// Worst case run time:
// 	Bits MSB through LSB+1:	11usec
// 	Bit LSB:				14usec
//
// Adds up to 100usec per byte which includes a comfortable margin
//

#pragma origin 4

interrupt int_server(void)
{
	int_save_registers

	if(INTF)
	{
		// Clear the interrupt
		INTF = 0;

#ifdef TWO_WIRE_INTERFACE
		// Clear the interface interrupt
		if(!RESET_BIT)
		{
			gLocalDataByte = 0x00;
			gDataMask = 0x80;

			int_restore_registers

			return;
		}
#endif

		// Shift in the data.  Data is sampled about 3.8usec after the interrupt edge.
		if(DATA_CARRIER)
		{
			gLocalDataByte |= gDataMask;
		}

		gDataMask >>= 1;
		if(!gDataMask)
		{
			gDataByte = gLocalDataByte;
			gDataByteReady = TRUE;
			gLocalDataByte = 0x00;
			gDataMask = 0x80;
		}

#ifdef ONE_WIRE_INTERFACE
		// Test for the interface reset signal
		if(DATA_CARRIER)
		{
			gLocalDataByte = 0x00;
			gDataMask = 0x80;
		}
#endif
	}

	int_restore_registers
}

///////////////////////////////////////////////////////////////////////////////
//
// Computes the blink interval
//
void computeBlinkInterval(byte n)
{
	gBlinkInterval = (word)(n);
	gBlinkInterval += 1;
	gBlinkInterval *= 160;

	gTimerHits = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Initializes communication RAM
//
void initCommRAM(void)
{
	gDataMask = 0x80;
	gLocalDataByte = 0x00;
	gDataByte = 0x00;
	gDataByteReady = FALSE;
}

///////////////////////////////////////////////////////////////////////////////
//
// Initializes function RAM
//
void initFuncRAM(void)
{
	gTest = 0x00;

	gBrightMask = 0x00;

	gDimMask = 0x00;
	gLocalDimMask = 0x80;

	gBlinkMask = 0x00;
	computeBlinkInterval(0);

	gTimerHits = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Performs the action from the data byte
//
void doAction(void)
{
	byte opcode;
	byte dataValue;
	byte mask;
	byte notMask;

	// Must match the device address
	if(ADDRESS_BIT)
	{
		if((gDataByte & TARGET_MASK) != TARGET_ADDRESS1) return;
	}
	else
	{
		if((gDataByte & TARGET_MASK) != TARGET_ADDRESS0) return;
	}

	// Any command cancels test mode
	if(gTest)
	{
		initFuncRAM();

		// All LEDs off
		PORTA = 0xFF;
		PORTB = 0xFF;
	}

	// Any command cancels all exclusive modes
	mask = gBrightMask | gDimMask | gBlinkMask;
	PORTA |= mask;
	PORTB |= mask;

	gBrightMask = 0x00;
	gDimMask = 0x00;
	gBlinkMask = 0x00;

	// Prepare come useful values
	opcode = gDataByte & OPCODE_MASK;
	opcode >>= 3;

	dataValue = gDataByte & DATA_MASK;

	mask = 1 << dataValue;
	notMask = ~mask;

	// Act on the opcode
	switch(opcode)
	{
		case OP_EXCLUSIVE_BRIGHT:
			gBrightMask = mask;

			break;

		case OP_EXCLUSIVE_DIM:
			gDimMask = mask;

			break;

		case OP_EXCLUSIVE_BLINK:
			gBlinkMask = mask;

			break;

		case OP_ALL:
			if(dataValue) notMask = 0x00;
			else notMask = 0xFF;

			PORTA = notMask;
			PORTB = notMask;

			break;

		case OP_ON:
			PORTA &= notMask;
			PORTB &= notMask;

			break;

		case OP_OFF:
			PORTA |= mask;
			PORTB |= mask;

			break;

		case OP_RATE:
			computeBlinkInterval(dataValue);

			break;

		case OP_TEST:
			if(dataValue) gTest = 0x80;
			else gTest = 0x00;

			break;

		default:
			break;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Brights the LEDs
//
void bright(void)
{
	byte notMask;

	notMask = ~gBrightMask;

	PORTA = notMask;
	PORTB = notMask;
}

///////////////////////////////////////////////////////////////////////////////
//
// Dims the LEDs
//
void dim(void)
{
	byte notMask;

	if(gDimMask & gLocalDimMask) notMask = ~gDimMask;
	else notMask = 0xFF;

	PORTA = notMask;
	PORTB = notMask;

	gLocalDimMask >>= 1;
	if(!gLocalDimMask) gLocalDimMask = 0x80;
}

///////////////////////////////////////////////////////////////////////////////
//
// Blinks the LEDs
//
void blink(void)
{
	gTimerHits++;
	if(gTimerHits >= gBlinkInterval)
	{
		// Blink
		PORTA ^= gBlinkMask;
		PORTB ^= gBlinkMask;

		gTimerHits = 0;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Runs the LED test
//
void test(void)
{
	byte notMask;

	notMask = ~gTest;

	PORTA = notMask;
	PORTB = notMask;

	gTest >>= 1;
	if(!gTest) gTest = 0x80;
}

///////////////////////////////////////////////////////////////////////////////
//
// Program starts here
//
void main(void)
{
	// Setup the port directions
	RP0 = 1;
	TRISA = 0x00;
#ifdef TWO_WIRE_INTERFACE
	TRISB = 0x0F;
#else
	TRISB = 0x09;
#endif
	RP0 = 0;

	// All LEDs off
	PORTA = 0xFF;
	PORTB = 0xFF;

	// Initialize the working RAM
	initCommRAM();

	initFuncRAM();

	RP0 = 1;
	// PortB pullups, RB0 interrupt on the rising edge, prescale /8
	OPTION = 0x42;
	RP0 = 0;

	// Set the timer rate
	TMR0 = TIMER_RATE;

	// Enable RB0 interrupt
	INTE = 1;
	GIE = 1;

	for(;;)
	{
		// Wait for a data byte
		if(gDataByteReady)
		{
			// Process the data byte
			doAction();

			// Reset the data byte ready flag
			gDataByteReady = FALSE;
		}

		// Handle some functions through the timer
		if(T0IF)
		{
			// Restart the timer
			TMR0 = TIMER_RATE;
			T0IF = 0;

			if(gTest)
			{
				test();
			}
			else if(gBrightMask)
			{
				bright();
			}
			else if(gDimMask)
			{
				dim();
			}
			else if(gBlinkMask)
			{
				blink();
			}
		}
	}
}

