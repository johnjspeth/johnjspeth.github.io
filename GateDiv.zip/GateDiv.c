/******************************************************************************

	PIC16F870 as a Programmable Gated Clock Divider
	-----------------------------------------------
	Copyright 2004 by John Speth

	This program takes an audio range VCO signal and generates a divided
	down sequencer step clock.  A 2msec step pulse is generated for every N
	number of VCO clocks.  N is selected via the pot voltage by using the
	on-chip ADC.

	The unique part of this circuit is that the step pulse output is
	synchronized with a gate signal if the gate plug is inserted.  An output
	step pulse conincides with the first VCO clock immediately after the gate
	asserts.

	This program also provides a secondary function of outputting a MIDI
	clock and a MIDI run/~stop signal.  This function is unrelated to the
	primary function.

	When the gate plug is not inserted, the output is a simple free running
	divide by N function.

	The VCO clock drives RB0 (pin 6).  It accepts 0V-5V logic levels.

	The gate input is on RB1 (pin 7).  It accepts 0V-5V logic levels.  When a
	plug is inserted in the gate socket, gate functions are enabled.  The
	gate plug switch shorts RB2 (pin 8) to ground when the gate plug is
	inserted.

	The divider selection pot voltage is on RA0 (pin 2).

	The step pulse output is on RB3 (pin 9).  If 24X (RB6, pin 27) is
	asserted, one step pulse is generated for every 24 MIDI clocks generated.

	                      +----------------+
	24X ----------------->| RB6            |
	                      |                |
	VCO in -------------->| RB0            |
	                      |                |
	Gate in ------------->| RB1        RB3 |---> Step pulse out
	                      |                |
	Gate plug switch ---->| RB2            |
	                      |                |
	Pot voltage in ------>| RA0            |
	                      +----------------+
	                      |            RB4 |---> MIDI clock out
	                      |                |
	MIDI receive in ----->| RC7        RB5 |---> MIDI run/~stop out
	                      |                |
	                      |            RC6 |---> MIDI transmit out
	                      +----------------+

	The circuit is implemented on two boards.  The secondary MIDI functions
	are brought out through a DIP16 connector.  The connector pinout is:

		1  - MIDI receive in
		2  - MIDI transmit out
		3  - MIDI clock out
		4  - MIDI run/~stop out
		5  - NC
		6  - NC
		7  - NC
		8  - NC
		9  - GND
		10 - GND
		11 - GND
		12 - GND
		13 - +5V
		14 - +5V
		15 - +5V
		16 - +5V

******************************************************************************/

#include <16f870.h>
#include <int16cxx.h>

// CPU hardware configuration
#pragma	config |= 0x3FFF
#pragma	config FOSC=HS, WDTE=off, PWRTE=on, BODEN=off
#define	LVP 0x0080
#pragma	config &= ~LVP

// Booleans
#define	TRUE						1
#define	FALSE						0

// Native data definitions
typedef unsigned char byte;
typedef unsigned long word;

// Port bit definitions
#pragma bit DIVIDER_POT_BIT			@ PORTA.0	// input - analog
#pragma bit RA1_BIT					@ PORTA.1	// output - unused
#pragma bit RA2_BIT					@ PORTA.2	// output - unused
#pragma bit RA3_BIT					@ PORTA.3	// output - unused
#pragma bit RA4_BIT					@ PORTA.4	// output - unused
#pragma bit RA5_BIT					@ PORTA.5	// output - unused

#pragma bit VCO_IN_BIT				@ PORTB.0	// input - digital
#pragma bit GATE_IN_BIT				@ PORTB.1	// input - digital
#pragma bit GATE_PLUG_REMOVED		@ PORTB.2	// input - digital
#pragma bit STEP_OUT_BIT			@ PORTB.3	// output - digital
#pragma bit MIDI_CLOCK_BIT			@ PORTB.4	// output - digital
#pragma bit MIDI_RUN_BIT			@ PORTB.5	// output - digital
#pragma bit MIDI_24X_BIT			@ PORTB.6	// input - digital
#pragma bit RB7_BIT					@ PORTB.7	// output - unused

#pragma bit RC0_BIT					@ PORTC.0	// output - unused
#pragma bit RC1_BIT					@ PORTC.1	// output - unused
#pragma bit RC2_BIT					@ PORTC.2	// output - unused
#pragma bit RC3_BIT					@ PORTC.3	// output - unused
#pragma bit RC4_BIT					@ PORTC.4	// output - unused
#pragma bit RC5_BIT					@ PORTC.5	// output - unused
#pragma bit RC6_BIT					@ PORTC.6	// output - MIDI serial transmit
#pragma bit RC7_BIT					@ PORTC.7	// input - MIDI serial receive

//
// Various macros
//

#define	TRANSMIT_MIDI_BYTE(b)		RP0 = 1; while(!TRMT); RP0 = 0; TXREG = (b)

#define	TIMER0_RATE					-79			// TMR0 value to achieve a 2msec rollover
#define	TIMER2_RATE					255			// TMR2 value to achieve the longest MIDI clock pulse possible

#define	GATE_PLUG_INSERTED			!GATE_PLUG_REMOVED

#define	MIDI_CLOCK					0xF8
#define	MIDI_START					0xFA
#define	MIDI_CONTINUE				0xFB
#define	MIDI_STOP					0xFC
#define	MIDI_RESET					0xFF

#define	PPQN						24

//
// Working RAM
//

// Used to track changes in the gate functions state
bit gPreviousGatePlugRemovedBit;
bit gPreviousGateIn;

// Signals the MIDI clock to pulse
bit gMidiClockSignal;

// Storage for the divider terminal count
long gDividerTerminalCount;
long gLastADCValue;

// Storage for MIDI clock 24X counter
int gMidiClock24XCount;

///////////////////////////////////////////////////////////////////////////////
//
// Interrupt handler
//

#pragma origin 4

interrupt int_server(void)
{
	byte midi;

	int_save_registers

	// Individual VCO clocks
	if(INTF && INTE)
	{
		// Clear the interrupt
		INTF = 0;

		if(GATE_PLUG_INSERTED)
		{
			// Set timer to overflow on the next VCO clock
			TMR1ON = 0;
			TMR1L = 0xFF;
			TMR1H = 0xFF;
			TMR1ON = 1;

			gMidiClock24XCount = 0;
		}

		// Disable VCO interrupt
		INTE = 0;
	}

	// VCO clocks internally divided
	if(TMR1IF)
	{
		// Clear the interrupt
		TMR1IF = 0;

		// Set timer to overflow at the prescribed divider value
		TMR1ON = 0;
		TMR1L = ~gDividerTerminalCount.low8;
		TMR1H = ~gDividerTerminalCount.high8;
		TMR1ON = 1;

		if(MIDI_24X_BIT)
		{
			if(gMidiClock24XCount == 0)
			{
				// Set the step pulse output
				STEP_OUT_BIT = 1;

				// And restart the 24X down counter
				gMidiClock24XCount = PPQN;
			}

			// Decrement the 24X down counter
			gMidiClock24XCount--;
		}
		else
		{
			// Set the step pulse output
			STEP_OUT_BIT = 1;

			// And always reset the 24X down counter
			gMidiClock24XCount = 0;
		}

		// Start the timer to clear the step pulse output
		TMR0 = TIMER0_RATE;
		T0IE = 1;

		// Signal a MIDI clock send
		gMidiClockSignal = 1;
	}

	// Step pulse output turn-off timer
	if(T0IF)
	{
		// Clear the interrupt
		T0IF = 0;

		// Clear the step pulse output
		STEP_OUT_BIT = 0;

		// Turn off the interrupt
		T0IE = 0;
	}

	// MIDI reception
	if(RCIF)
	{
		// Read the byte and clear the interrupt
		midi = RCREG;

		// Handle the MIDI byte
		if(midi == MIDI_CLOCK)
		{
			// Clear the clock pin
			MIDI_CLOCK_BIT = 1;

			// Start the clock pulse turn-off timer
			TMR2ON = 0;
			TMR2 = 0;
			TMR2ON = 1;

			RP0 = 1;
			TMR2IE = 1;
			RP0 = 0;
		}
		else if(midi == MIDI_START)
		{
			// Set the run bit
			MIDI_RUN_BIT = 1;
		}
		else if(midi == MIDI_CONTINUE)
		{
			// Set the run bit
			MIDI_RUN_BIT = 1;
		}
		else if(midi == MIDI_STOP)
		{
			// Clear the run bit
			MIDI_RUN_BIT = 0;
		}
		else if(midi == MIDI_RESET)
		{
			// Clear the run and clock bits
			MIDI_CLOCK_BIT = 0;
			MIDI_RUN_BIT = 0;
		}
	}

	// MIDI clock pulse turn-off timer
	if(TMR2IF)
	{
		// Clear the interrupt
		TMR2IF = 0;

		// Turn off the timer
		TMR2ON = 0;

		// Disable the interrupt
		RP0 = 1;
		TMR2IE = 0;
		RP0 = 0;

		// Clear the clock pin
		MIDI_CLOCK_BIT = 0;
	}

	int_restore_registers
}

///////////////////////////////////////////////////////////////////////////////
//
// Configures the VCO divider
//
void configureVCODivider(void)
{
	// Turn off the timer
	TMR1ON = 0;

	if(GATE_PLUG_REMOVED)
	{
		// Disable VCO interrupt
		INTE = 0;

		// Set timer to overflow at the prescribed divider value
		TMR1ON = 0;
		TMR1L = ~gDividerTerminalCount.low8;
		TMR1H = ~gDividerTerminalCount.high8;
		TMR1ON = 1;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Handles MIDI clock signals
//
void handleMIDIClock(void)
{
	if(gMidiClockSignal)
	{
		gMidiClockSignal = 0;

		// Send MIDI clock
		TRANSMIT_MIDI_BYTE(MIDI_CLOCK);
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Handles changes to the gate signal
//
void handleGateChanges(void)
{
	bit gateInBit;

	gateInBit = GATE_IN_BIT;
	if(!gPreviousGateIn && gateInBit)
	{
		// Send MIDI start
		TRANSMIT_MIDI_BYTE(MIDI_START);

		// Enable VCO interrupt
		INTE = 1;
	}
	else if(gPreviousGateIn && !gateInBit)
	{
		// Send MIDI Stop
		TRANSMIT_MIDI_BYTE(MIDI_STOP);

		// Turn off the timer
		TMR1ON = 0;
	}
	gPreviousGateIn = gateInBit;
}

///////////////////////////////////////////////////////////////////////////////
//
// Delays Nx10 us
//
void delay10us(int n)
{
	while(n)
	{
		nop(); nop(); nop(); nop(); nop();
		nop(); nop(); nop(); nop(); nop();
		nop(); nop(); nop(); nop(); nop();
		nop(); nop(); nop();

		n--;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Converts the ADC value to a properly spread value
//
long convertPotValue(long adc)
{
	long n;

	n = 1023 - adc;

	if(n <= 9L) n = 0L;
	else if(n <= 249L) n /= (uns16)(10);
	else n -= 225L;

	return n;
}

///////////////////////////////////////////////////////////////////////////////
//
// Gets the initial ADC divider value
//
void getFirstDividerValue(void)
{
	// Time to acquire
	delay10us(10);

	// Start a conversion and wait for the result
	GO = 1;
	while(GO);

	RP0 = 1;
	W = ADRESL;
	RP0 = 0;
	gLastADCValue.low8 = W;
	gLastADCValue.high8 = ADRESH;

	gDividerTerminalCount = convertPotValue(gLastADCValue);

	// Time to acquire
	delay10us(10);

	// Start another conversion
	GO = 1;
}

///////////////////////////////////////////////////////////////////////////////
//
// Manages the use of the ADC for getting the VCO divider value
//
void handleADC(void)
{
	long adc;
	long diff;
	long div;

	// Get the divider value from the pot through the ADC when it's ready
	if(!GO)
	{
		// Get the result
		RP0 = 1;
		W = ADRESL;
		RP0 = 0;
		adc.low8 = W;
		adc.high8 = ADRESH;

		// Prevent changes due to ADC chatter
		diff = gLastADCValue - adc;
		if((diff > 1L) || (diff < -1L))
		{
			gLastADCValue = adc;

			// Store the divider value for the next time around
			div = convertPotValue(adc);

			GIE = 0;
			gDividerTerminalCount = div;
			GIE = 1;
		}

		// Time to acquire
		delay10us(10);

		// Start another conversion
		GO = 1;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Initializes the working RAM
//
void initializeWorkingRAM(void)
{
	gPreviousGatePlugRemovedBit = GATE_PLUG_REMOVED;
	gPreviousGateIn = GATE_IN_BIT;
	gMidiClockSignal = 0;
	gMidiClock24XCount = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Program starts here
//
void main(void)
{
	bit gatePlugRemovedBit;

	// Setup the port directions
	RP0 = 1;
	TRISA = 0x01;	// RA0 analog input, RA1-5 output
	TRISB = 0x47;	// RB0-2 input, RB3-5 output, RB6 input, RB7 output
	TRISC = 0x81;	// RC0 input, RC1-6 output, RC7 input
	RP0 = 0;

	// Initialize parallel port output
	PORTA = 0x00;
	PORTB = 0x00;
	PORTC = 0x00;

	// PortB pullups, RB0 interrupt on the rising edge, timer0 prescale /64
	RP0 = 1;
	OPTION = 0x45;
	RP0 = 0;

	// Set the step pulse turn-off timer on timer0
	TMR0 = TIMER0_RATE;

	// Set the VCO pulse counter on timer1
	// Timer1 prescale /1, oscillator off, synchronous, external clock, timer disabled
	T1CON = 0x02;

	// Enable the interrupt
	RP0 = 1;
	TMR1IE = 1;
	RP0 = 0;

	// Set the MIDI pulse turn-off timer on timer2
	// Timer2 postscale /1, prescale /16, timer disabled
	T2CON = 0x02;
	TMR2 = 0;
	RP0 = 1;
	PR2 = TIMER2_RATE;
	RP0 = 0;

	// ADC right justified output, RA0 is the sole analog input
	RP0 = 1;
	ADCON1 = 0x8E;
	RP0 = 0;

	// ADC clock = Fosc/32, select AN0 input, stop conversion, turn on ADC circuit
	ADCON0 = 0x81;

	// Configure MIDI reception
	RP0 = 1;
	SPBRG = 19;
	TXSTA = 0x24;
	RP0 = 0;
	RCSTA = 0x80;

	// Initialize working RAM
	initializeWorkingRAM();

	// More setup
	getFirstDividerValue();
	configureVCODivider();

	// Turn on MIDI reception and enable the MIDI receive interrupt
	W = RCREG;
	CREN = 1;
	RP0 = 1;
	RCIE = 1;
	RP0 = 0;

	// Enable interrupts
	PEIE = 1;
	GIE = 1;

	// Main loop
	for(;;)
	{
		// Watch the gate functions bit
		gatePlugRemovedBit = GATE_PLUG_REMOVED;
		if(gatePlugRemovedBit != gPreviousGatePlugRemovedBit) configureVCODivider();
		gPreviousGatePlugRemovedBit = gatePlugRemovedBit;

		// Watch for gate changes
		handleGateChanges();

		// Handle the ADC
		handleADC();

		// Handle MIDI clock signals
		handleMIDIClock();
	}
}

