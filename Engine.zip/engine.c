/******************************************************************************

	PIC16F877 as a Sequencer Engine
	-------------------------------
	Copyright 2004 by John Speth

	The sequencer engine has:

		1 step input - 5V rising edge triggered
		1 gate input - 0V is no gate, 5V is gate
		2 step trigger outputs - 5V rising edge is the trigger

	The step input accepts 0V-5V logic levels.

	The gate input accepts 0V-5V logic levels.  When a plug is inserted in
	the gate socket, the gate functions are enabled.  There is a step out
	trigger for each row.  When 1x16 mode is selected, both step out triggers
	assert in unison.  When 2x8 mode is selected, the step out triggers
	assert independently.

	The LED interface connects through a DIP16 connector which carries all
	digital signals and power.  The scanner interface connects through a
	DIP16 connector which carries all digital signals and power.

	The run/stop mode gates external step clock to the sequencer.  Manual
	stepping is not disabled in stop mode.  The row mode is selectable as
	1x16 or 2x8.  The direction mode is selectable as up or up/down.

	There are two gate functions that are available only when the gate plug
	is inserted: oneshot mode and return-to-sero (RTZ) mode.  When both
	oneshot and RTZ mode are off, the gate signal provides a run/stop type
	sequencing gate.  When RTZ mode is on, the sequence always starts at the
	first non-skipped stage when the gate asserts.  When oneshot mode is on,
	a single complete sequencer cycle executes to completion at the step
	input rate when the gate asserts regardless of the state of the gate
	signal after the gate asserts.

******************************************************************************/

#include <16f877.h>
#include <int16cxx.h>

// CPU hardware configuration
#pragma	config |= 0x3FFF
#pragma	config FOSC=HS, WDTE=off, PWRTE=on, BODEN=off

// Disable low voltage programming
#define	LVP 0x0080
#pragma	config &= ~LVP

// Booleans
#define	TRUE						1
#define	FALSE						0

// Native data definitions
typedef unsigned char byte;
typedef unsigned long word;

// Port bit definitions
#pragma bit IRESET_OUT_BIT			@ PORTA.0	// Output: 1=not asserted, 0=asserted
#pragma bit LED_CLOCK_BIT			@ PORTA.1	// Output
#pragma bit LED_DATA_BIT			@ PORTA.2	// Output
#pragma bit SCANNER_CLOCK_BIT		@ PORTA.3	// Output
#pragma bit SCANNER_DATA_BIT		@ PORTA.4	// Input
#pragma bit MCLR_OUT_BIT			@ PORTA.5	// Output: 1=not asserted, 0=asserted

#pragma bit STEP_IN_BIT				@ PORTB.0	// Input
#pragma bit GATE_IN_BIT				@ PORTB.1	// Input; 1=gate asserted, 0=gate not asserted
#pragma bit GATE_PLUG_REMOVED		@ PORTB.2	// Input: 1=gate plug not inserted, 0=gate plug inserted
#pragma bit RB3_BIT					@ PORTB.3	// Output - unused
#pragma bit STEP_OUT_ROW1_BIT		@ PORTB.4	// Output
#pragma bit STEP_OUT_ROW2_BIT		@ PORTB.5	// Output
#pragma bit RB6_BIT					@ PORTB.6	// Output - PGC programming pin
#pragma bit RB7_BIT					@ PORTB.7	// Output - PGD programming pin

#pragma bit ROW1_DRIVE0_BIT			@ PORTC.0	// Output
#pragma bit ROW1_DRIVE1_BIT			@ PORTC.1	// Output
#pragma bit ROW1_DRIVE2_BIT			@ PORTC.2	// Output
#pragma bit ROW1_DRIVE3_BIT			@ PORTC.3	// Output
#pragma bit ROW2_DRIVE0_BIT			@ PORTC.4	// Output
#pragma bit ROW2_DRIVE1_BIT			@ PORTC.5	// Output
#pragma bit ROW2_DRIVE2_BIT			@ PORTC.6	// Output
#pragma bit ROW2_DRIVE3_BIT			@ PORTC.7	// Output

//
// Various macros
//

#define	WAIT_TIMER_INTERVAL()		while(!T0IF); TMR0 = TMR0_RATE; T0IF = 0
#define	DELAY_LED(n)				for(d = n; d; d--)

// Maximum stage counts
#define	MAX_2X8						8
#define	MAX_1X16					16

// The number of switches
#define	NUM_SWITCHES				40

// The number of switch status storage bytes
#define	NUM_SWITCH_STATUS_BYTES		5

// TMR0 value to achieve a 5msec rollover
#define	TMR0_RATE					-195

// TMR1 value to achieve a 2msec rollover
#define	TMR1L_RATE					0x78
#define	TMR1H_RATE					0xEC

// LED driver addresses
#define	LED_ADRS_ROW1				0x00
#define	LED_ADRS_ROW2				0x40

// LED attributes
#define	LED_BRIGHT					0x00
#define	LED_DIM						0x08
#define	LED_BLINK					0x10
#define	LED_ALL						0x18
#define	LED_RATE					0x30
#define	LED_TEST					0x38

#define	ALL_ON						0
#define	ALL_OFF						7

#define	UNASSIGNED					0xFF
#define	PAUSE						0x80

// Row skip/pause flags
#define	ROW1_SKIP_FLAGS				gSwitchByte[2]
#define	ROW1_PAUSE_FLAGS			gSwitchByte[3]
#define	ROW2_SKIP_FLAGS				gSwitchByte[0]
#define	ROW2_PAUSE_FLAGS			gSwitchByte[1]

// Switch definitions
#define	MANUAL_STEP					gSwitchByte[4].7	// Manual step
#define	RUN_MODE					gSwitchByte[4].6	// Run mode selection
#define	ONE_BY_16_MODE				gSwitchByte[4].5	// 2x8 or 1x16 mode selection
#define	UPDOWN_MODE					gSwitchByte[4].4	// Up/down vs. up mode selection
#define	ONESHOT_MODE				gSwitchByte[4].3	// Oneshot mode selection (gate function)
#define	RTZ_MODE					gSwitchByte[4].2	// Return-to-zero mode selection (gate function)
#define	RAND_MODE					gSwitchByte[4].1	// Random

#define	GATE_FUNCTIONS				!GATE_PLUG_REMOVED	// Gate function selector

//
// Working RAM
//

// RAM bank 0 is used for all common functionality
#pragma rambank 0	// 12 bytes

// Switch states
byte gSwitchByte[NUM_SWITCH_STATUS_BYTES];

// For tracking the manual-step switch
bit gPreviousManualStep;
bit gManualStepSignal;

// For tracking the gate-in signal
bit gPreviousGateIn;
bit gGateSignal;

// Other
bit gReadingStepListB;
bit gEffectiveOneshotMode;

// Row output indices
int gRow1Index;						// 2x8 mode
int gRow2Index;						// 2x8 mode
int gRowIndex;						// 1x16 mode

// Pseudorandom number generator storage
byte gRandHi;
byte gRandMid;
byte gRandLo;

// RAM bank 1 is used for 2x8 mode functionality
#pragma rambank 1	// 68 bytes

// Dual step list storage
byte gRow1StepListA[MAX_2X8 * 2];
byte gRow1StepCountA;
byte gRow2StepListA[MAX_2X8 * 2];
byte gRow2StepCountA;
byte gRow1StepListB[MAX_2X8 * 2];
byte gRow1StepCountB;
byte gRow2StepListB[MAX_2X8 * 2];
byte gRow2StepCountB;

// RAM bank 1 is used for 1x16 mode functionality
#pragma rambank 2	// 66 bytes

byte gRowStepListA[MAX_1X16 * 2];
byte gRowStepCountA;
byte gRowStepListB[MAX_1X16 * 2];
byte gRowStepCountB;

// Forward references
extern void ledISR(byte adrs,byte index,byte attribute);
extern int step(void);
extern void resetRows(void);
extern byte rand(byte limit);

///////////////////////////////////////////////////////////////////////////////
//
// Interrupt handler
//

#pragma origin 4

interrupt int_server(void)
{
	int_save_registers
	char sv_FSR = FSR;

	// Step input
	if(INTF)
	{
		// Clear the interrupt
		INTF = 0;

		if(gManualStepSignal)
		{
			if(step()) gGateSignal = FALSE;

			gManualStepSignal = FALSE;
		}
		else if(RUN_MODE)
		{
			if(GATE_FUNCTIONS)
			{
				if(gEffectiveOneshotMode)
				{
					if(gGateSignal)
					{
						if(step())
						{
							resetRows();
							gGateSignal = FALSE;
						}
					}
				}
				else
				{
					if(GATE_IN_BIT)
					{
						step();
					}
					else
					{
						if(RTZ_MODE) resetRows();
					}

					gGateSignal = FALSE;
				}
			}
			else
			{
				step();
				gGateSignal = FALSE;
			}
		}
		else
		{
			gGateSignal = FALSE;
		}
	}

	// Step out clear
	if(TMR1IF)
	{
		// Clear the interrupt
		TMR1IF = 0;

		// Turn off TMR1
		TMR1ON = 0;

		// Turn off the step out lines
		STEP_OUT_ROW1_BIT = 0;
		STEP_OUT_ROW2_BIT = 0;
	}

	FSR = sv_FSR;
	int_restore_registers
}

// Include the const data and LCD API
#include "data.c"
#include "lcd.c"

#define	LED_MACRO(adrs,index,attribute) \
	byte value; \
	byte mask; \
	byte d; \
	int i; \
 \
	IRESET_OUT_BIT = 0; \
	LED_CLOCK_BIT = 0; \
	LED_CLOCK_BIT = 1; \
	DELAY_LED(1); \
	IRESET_OUT_BIT = 1; \
 \
	index ^= 0x07; \
	value = adrs | attribute | index; \
	mask = 0x80; \
 \
	DELAY_LED(3); \
 \
	for(i = 0; i < 8; i++) \
	{ \
		if(value & mask) LED_DATA_BIT = 1; \
		else LED_DATA_BIT = 0; \
 \
		LED_CLOCK_BIT = 0; \
		LED_CLOCK_BIT = 1; \
 \
		mask >>= 1; \
 \
		DELAY_LED(2); \
	} \
 \
	LED_CLOCK_BIT = 0; \
	LED_DATA_BIT = 0;

///////////////////////////////////////////////////////////////////////////////
//
// Drives the LEDs (about 150usec @ 10MHz) - ISR use
//
void ledISR(byte adrs,byte index,byte attribute)
{
	LED_MACRO(adrs,index,attribute);
}

///////////////////////////////////////////////////////////////////////////////
//
// Drives the LEDs (about 150usec @ 10MHz) - Foreground use
//
void ledFG(byte adrs,byte index,byte attribute)
{
	LED_MACRO(adrs,index,attribute);
}

///////////////////////////////////////////////////////////////////////////////
//
// Steps the sequencer
// Returns true if the end of the list has been run and false if not
//
int step(void)
{
	bit stepRow1;
	bit stepRow2;
	bit endOfList;
	byte analogOutput;
	byte *pRowStepList;
	byte *pRowStepCount;
	byte cell;
	byte index;
	byte attribute;
	byte ledIndexRow1;
	byte ledIndexRow2;
	byte ledAttribRow1;
	byte ledAttribRow2;

	stepRow1 = FALSE;
	stepRow2 = FALSE;
	endOfList = FALSE;

	analogOutput = 0x00;

	if(ONE_BY_16_MODE)
	{
		// Point to the destination list
		if(gReadingStepListB)
		{
			pRowStepList = gRowStepListB;
			pRowStepCount = &gRowStepCountB;
		}
		else
		{
			pRowStepList = gRowStepListA;
			pRowStepCount = &gRowStepCountA;
		}

		// Check the index for wrap-around
		if(pRowStepList[gRowIndex] == UNASSIGNED) gRowIndex = 0;

		// Point to the current cell
		cell = pRowStepList[gRowIndex];
		if(cell == UNASSIGNED)
		{
			// Do nothing if no steps are active
			ledIndexRow1 = ALL_OFF;
			ledIndexRow2 = ALL_OFF;

			ledAttribRow1 = LED_ALL;
			ledAttribRow2 = LED_ALL;

			analogOutput = PORTC;
		}
		else
		{
			// Decode and build the analog output
			index = cell & 0x0F;
			if(cell & PAUSE)
			{
				attribute = LED_DIM;
				analogOutput = PORTC;
			}
			else
			{
				attribute = LED_BRIGHT;
				analogOutput = index | swap(index);
				stepRow1 = TRUE;
				stepRow2 = TRUE;
			}

			// Select the LEDs
			if(index < 8)
			{
				ledIndexRow1 = index;
				ledIndexRow2 = ALL_OFF;

				ledAttribRow1 = attribute;
				ledAttribRow2 = LED_ALL;
			}
			else
			{
				ledIndexRow1 = ALL_OFF;
				ledIndexRow2 = index - 8;

				ledAttribRow1 = LED_ALL;
				ledAttribRow2 = attribute;
			}
		}

		// Increment the index
		if(RAND_MODE) gRowIndex = rand(*pRowStepCount);
		else gRowIndex++;

		// Check for the end of the list
		if(pRowStepList[gRowIndex] == UNASSIGNED) endOfList = TRUE;
	}
	else
	{
		//
		// Row 1
		//

		// Point to the destination list
		if(gReadingStepListB)
		{
			pRowStepList = gRow1StepListB;
			pRowStepCount = &gRow1StepCountB;
		}
		else
		{
			pRowStepList = gRow1StepListA;
			pRowStepCount = &gRow1StepCountA;
		}

		// Check the index for wrap-around
		if(pRowStepList[gRow1Index] == UNASSIGNED) gRow1Index = 0;

		// Point to the current cell
		cell = pRowStepList[gRow1Index];
		if(cell == UNASSIGNED)
		{
			// Do nothing if no steps are active
			ledIndexRow1 = ALL_OFF;
			ledAttribRow1 = LED_ALL;
			analogOutput |= PORTC & 0x0F;
		}
		else
		{
			// Decode and build the analog output
			index = cell & 0x0F;
			ledIndexRow1 = index;
			if(cell & PAUSE)
			{
				ledAttribRow1 = LED_DIM;
				analogOutput |= PORTC & 0x0F;
			}
			else
			{
				ledAttribRow1 = LED_BRIGHT;
				stepRow1 = TRUE;
				analogOutput |= index;
			}
		}

		// Increment the index
		if(RAND_MODE) gRow1Index = rand(*pRowStepCount);
		else gRow1Index++;

		// Check for the end of the list
		if(pRowStepList[gRow1Index] == UNASSIGNED) endOfList = TRUE;

		//
		// Row 2
		//

		// Point to the destination list
		if(gReadingStepListB)
		{
			pRowStepList = gRow2StepListB;
			pRowStepCount = &gRow2StepCountB;
		}
		else
		{
			pRowStepList = gRow2StepListA;
			pRowStepCount = &gRow2StepCountA;
		}

		// Check the index for wrap-around
		if(pRowStepList[gRow2Index] == UNASSIGNED) gRow2Index = 0;

		// Point to the current cell
		cell = pRowStepList[gRow2Index];
		if(cell == UNASSIGNED)
		{
			// Do nothing if no steps are active
			ledIndexRow2 = ALL_OFF;
			ledAttribRow2 = LED_ALL;
			analogOutput |= PORTC & 0xF0;
		}
		else
		{
			// Decode and build the analog output
			index = cell & 0x0F;
			ledIndexRow2 = index;
			if(cell & PAUSE)
			{
				ledAttribRow2 = LED_DIM;
				analogOutput |= PORTC & 0xF0;
			}
			else
			{
				ledAttribRow2 = LED_BRIGHT;
				stepRow2 = TRUE;
				analogOutput |= swap(index);
			}
		}

		// Increment the index
		if(RAND_MODE) gRow2Index = rand(*pRowStepCount);
		else gRow2Index++;

		// Check for the end of the list
		if(pRowStepList[gRow2Index] == UNASSIGNED) endOfList = TRUE;
	}

	// Final analog output
	PORTC = analogOutput;

	// Start the step out cancellation timer
	TMR1ON = 0;
	TMR1L = TMR1L_RATE;
	TMR1H = TMR1H_RATE;
	TMR1ON = 1;

	// Set the step out lines
	if(stepRow1) STEP_OUT_ROW1_BIT = 1;
	if(stepRow2) STEP_OUT_ROW2_BIT = 1;

	// LED output
	ledISR(LED_ADRS_ROW1,ledIndexRow1,ledAttribRow1);
	ledISR(LED_ADRS_ROW2,ledIndexRow2,ledAttribRow2);

	if(endOfList) return TRUE;
	else return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
//
// Resets the row indices
//
void resetRows(void)
{
	gRow1Index = 0;
	gRow2Index = 0;
	gRowIndex = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Queries the switch scanner (about 1ms @ 10MHz)
//
page1 void querySwitchScanner(void)
{
	#define	DELAY_SCAN(n)	for(d = n; d; d--)
	int index;
	byte mask;
	byte d;
	int i;

	// Reset the interface
	IRESET_OUT_BIT = 0;
	SCANNER_CLOCK_BIT = 0;
	SCANNER_CLOCK_BIT = 1;
	DELAY_SCAN(2);
	IRESET_OUT_BIT = 1;

	// Initialize indices
	index = 0;
	mask = 0x80;

	for(i = 0; i < NUM_SWITCHES; i++)
	{
		SCANNER_CLOCK_BIT = 0;
		SCANNER_CLOCK_BIT = 1;

		DELAY_SCAN(4);

		if(SCANNER_DATA_BIT) gSwitchByte[index] &= ~mask;
		else gSwitchByte[index] |= mask;

		mask >>= 1;
		if(!mask)
		{
			mask = 0x80;
			index++;
		}
	}

	// Ready for reset again
	SCANNER_CLOCK_BIT = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Builds the step list for the given switch settings
//
page1 void buildStepList(void)
{
	int i;
	byte mask;
	byte output;
	int position;
	byte *pRowStepList;
	byte *pRowStepCount;
	int count;
	int index;

	if(ONE_BY_16_MODE)
	{
		// Point to the destination list
		if(gReadingStepListB)
		{
			pRowStepList = gRowStepListA;
			pRowStepCount = &gRowStepCountA;
		}
		else
		{
			pRowStepList = gRowStepListB;
			pRowStepCount = &gRowStepCountB;
		}

		// Row 1
		mask = 0x01;
		position = 0;

		for(i = 0; i < MAX_2X8; i++)
		{
			if(!(ROW1_SKIP_FLAGS & mask))
			{
				output = (byte)(i);;
				if(ROW1_PAUSE_FLAGS & mask) output |= PAUSE;

				pRowStepList[position++] = output;
			}

			mask <<= 1;
		}

		// Row 2
		mask = 0x01;

		for(i = 0; i < MAX_2X8; i++)
		{
			if(!(ROW2_SKIP_FLAGS & mask))
			{
				output = (byte)(i + 8);;
				if(ROW2_PAUSE_FLAGS & mask) output |= PAUSE;

				pRowStepList[position++] = output;
			}

			mask <<= 1;
		}

		// Handle the down count
		if(UPDOWN_MODE)
		{
			count = position - 2;
			for(i = 0; i < count; i++)
			{
				index = count - i;
				output = pRowStepList[index];
				pRowStepList[position++] = output;
			}
		}

		// Terminate the list
		pRowStepList[position] = UNASSIGNED;
		*pRowStepCount = position;
	}
	else
	{
		// Point to the destination list
		if(gReadingStepListB)
		{
			pRowStepList = gRow1StepListA;
			pRowStepCount = &gRow1StepCountA;
		}
		else
		{
			pRowStepList = gRow1StepListB;
			pRowStepCount = &gRow1StepCountB;
		}

		// Prepare the row 1 list
		mask = 0x01;
		position = 0;

		for(i = 0; i < MAX_2X8; i++)
		{
			if(!(ROW1_SKIP_FLAGS & mask))
			{
				output = (byte)(i);;
				if(ROW1_PAUSE_FLAGS & mask) output |= PAUSE;

				pRowStepList[position++] = output;
			}

			mask <<= 1;
		}

		// Handle the down count
		if(UPDOWN_MODE)
		{
			count = position - 2;
			for(i = 0; i < count; i++)
			{
				index = count - i;
				output = pRowStepList[index];
				pRowStepList[position++] = output;
			}
		}

		// Terminate the list
		pRowStepList[position] = UNASSIGNED;
		*pRowStepCount = position;

		// Point to the destination list
		if(gReadingStepListB)
		{
			pRowStepList = gRow2StepListA;
			pRowStepCount = &gRow2StepCountA;
		}
		else
		{
			pRowStepList = gRow2StepListB;
			pRowStepCount = &gRow2StepCountB;
		}

		// Prepare the row 2 list
		mask = 0x01;
		position = 0;

		for(i = 0; i < MAX_2X8; i++)
		{
			if(!(ROW2_SKIP_FLAGS & mask))
			{
				output = (byte)(i);;
				if(ROW2_PAUSE_FLAGS & mask) output |= PAUSE;

				pRowStepList[position++] = output;
			}

			mask <<= 1;
		}

		// Handle the down count
		if(UPDOWN_MODE)
		{
			count = position - 2;
			for(i = 0; i < count; i++)
			{
				index = count - i;
				output = pRowStepList[index];
				pRowStepList[position++] = output;
			}
		}

		// Terminate the list
		pRowStepList[position] = UNASSIGNED;
		*pRowStepCount = position;
	}

	// Toggle the source list indicator
	gReadingStepListB ^= 1;
}

///////////////////////////////////////////////////////////////////////////////
//
// Seeds the LFSR pseudorandom generator
//
page1 void srand(byte ms,byte ls)
{
	gRandHi = 0x01;
	gRandMid = ms;
	gRandLo = ls;
}

///////////////////////////////////////////////////////////////////////////////
//
// Generates a pseudorandom number from a 17 stage LFSR
//
byte rand(byte limit)
{
	byte r;

	if(limit == 0) return limit;

	// Shift 17 bits left
	gRandHi <<= 1;
	if(gRandMid.7) gRandHi.0 = 1;

	gRandMid <<= 1;
	if(gRandLo.7) gRandMid.0 = 1;

	gRandLo <<= 1;

	// XOR bits 17 and 14 and store into bit 1
	gRandLo.0 = gRandMid.5 ^ gRandHi.0;

	// Limit the result
	r = gRandLo;
	r %= limit;

	// Return the result
	return r;
}

///////////////////////////////////////////////////////////////////////////////
//
// Initializes the working RAM
//
page1 void initializeWorkingRAM(void)
{
	int i;

	gPreviousManualStep = FALSE;
	gManualStepSignal = MANUAL_STEP;
	gPreviousGateIn = GATE_IN_BIT;
	gGateSignal = GATE_IN_BIT;
	gEffectiveOneshotMode = FALSE;

	gRow1Index = 0;
	gRow2Index = 0;
	gRowIndex = 0;

	for(i = 0; i < NUM_SWITCH_STATUS_BYTES; i++) gSwitchByte[i] = 0x00;

	for(i = 0; i < (MAX_2X8 * 2); i++)
	{
		gRow1StepListA[i] = UNASSIGNED;
		gRow2StepListA[i] = UNASSIGNED;
		gRow1StepListB[i] = UNASSIGNED;
		gRow2StepListB[i] = UNASSIGNED;
	}

	gRow1StepCountA = 0;
	gRow2StepCountA = 0;
	gRow1StepCountB = 0;
	gRow2StepCountB = 0;

	for(i = 0; i < (MAX_1X16 * 2); i++)
	{
		gRowStepListA[i] = UNASSIGNED;
		gRowStepListB[i] = UNASSIGNED;
	}

	gRowStepCountA = 0;
	gRowStepCountB = 0;

	gReadingStepListB = FALSE;
}

///////////////////////////////////////////////////////////////////////////////
//
// Programmed delay
//
page1 void delay(byte n)
{
	byte i;

	for(i = 0; i < n; i++)
	{
		WAIT_TIMER_INTERVAL();
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Resets the LED controllers and the switch scanner
//
page1 void resetExternalDevices(void)
{
	MCLR_OUT_BIT = 0;
	delay(2);
	MCLR_OUT_BIT = 1;
	delay(4);
}

///////////////////////////////////////////////////////////////////////////////
//
// Arbitrates onehsot and random modes
//
page1 void arbitrateOneshotMode(void)
{
	// Arbitrate onehsot and random modes
	if(GATE_FUNCTIONS)
	{
		// Oneshot mode is not possible if random mode is on and vice versa
		if(RAND_MODE) gEffectiveOneshotMode = FALSE;
		else gEffectiveOneshotMode = ONESHOT_MODE;
	}
	else
	{
		gEffectiveOneshotMode = FALSE;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// Updates status on the LCD
//
page1 void updateLCDStatus(void)
{
}

///////////////////////////////////////////////////////////////////////////////
//
// Program starts here
//
void main(void)
{
	bit manualStep;
	bit gateInBit;

	// Setup the port directions
	RP0 = 1;
	ADCON1 = 0x06;	// Make all analog pins digital
	TRISA = 0x10;	// RA0-3 output, RA4 input,
	TRISB = 0x07;	// RB0-2 input, RB3-7 output
	TRISC = 0x00;	// RC0-7 output
	TRISD = 0xFF;	// RD0-7 input to start
	TRISE = 0x00;	// RE0-2 output
	RP0 = 0;

	// Initialize parallel port output
	PORTA = 0x00;
	PORTB = 0x00;
	PORTC = 0x00;

	IRESET_OUT_BIT = 1;
	MCLR_OUT_BIT = 1;

	// PortB pullups, RB0 interrupt on the rising edge, prescale /64
	RP0 = 1;
	OPTION = 0x45;
	RP0 = 0;

	// Set the TMR0 rate
	TMR0 = TMR0_RATE;

	// TMR1 prescale /1, oscillator off, internal clock, timer disabled
	T1CON = 0x00;

	// Reset external devices
	resetExternalDevices();

	// Initialize the LCD
	lcdInit();
	lcdSpecific(0,0,gTopBanner);
	lcdSpecific(1,0,gBottomBottom);

	// Light up LEDs during initialization
	ledFG(LED_ADRS_ROW1,ALL_ON,LED_ALL);
	ledFG(LED_ADRS_ROW2,ALL_ON,LED_ALL);
	delay(50);

	// Initialize working RAM
	initializeWorkingRAM();

	// More initialization
	querySwitchScanner();
	buildStepList();

	// Seed the random number generator
	if(ROW1_SKIP_FLAGS || ROW2_SKIP_FLAGS) srand(ROW1_SKIP_FLAGS,ROW2_SKIP_FLAGS);
	else srand(0x23,0x45);

	// Enable TMR1 interrupt
	RP0 = 1;
	TMR1IE = 1;
	RP0 = 0;

	// Enable RB0 interrupt
	INTE = 1;

	// Enable all interrupts
	PEIE = 1;
	GIE = 1;

	// Turn off LEDs
	ledFG(LED_ADRS_ROW1,ALL_OFF,LED_ALL);
	ledFG(LED_ADRS_ROW2,ALL_OFF,LED_ALL);

	// Main loop
	for(;;)
	{
		// Watch for gate changes
		gateInBit = GATE_IN_BIT;
		if(gateInBit && !gPreviousGateIn)
		{
			if(RTZ_MODE)
			{
				GIE = 0;
				resetRows();
				GIE = 1;
			}

			gGateSignal = TRUE;
		}
		gPreviousGateIn = gateInBit;

		// Query the switch scanner at timed intervals
		if(T0IF)
		{
			// Clear the interrupt
			T0IF = 0;

			// Restart TMR0
			TMR0 = TMR0_RATE;

			// Read the switches
			querySwitchScanner();

			// Watch for manual steps
			manualStep = MANUAL_STEP;
			if(manualStep && !gPreviousManualStep)
			{
				gManualStepSignal = TRUE;
				INTF = 1;
			}
			gPreviousManualStep = manualStep;

			// Do the rest
			buildStepList();
			arbitrateOneshotMode();
			updateLCDStatus();
		}
	}
}

