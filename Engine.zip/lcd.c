/******************************************************************************

	LCD API
	-------
	Copyright 2004 by John Speth

******************************************************************************/

#define	TWO_WAY_LCD

//
// LCD interface bit definitions
//
#pragma bit LCD_ENABLE_BIT		@ PORTE.0	// Output: 1=not asserted, 0=asserted
#pragma bit LCD_RS_BIT			@ PORTE.1	// Output: 1=data, 0=command
#pragma bit LCD_RW_BIT			@ PORTE.2	// Output: 1=read from LCD, 0=write to LCD

//
// LCD command codes
//
#define	FUNC_CLEAR_DISPLAY		0x01		// Clear display
#define	FUNC_HOME				0x02		// Return home
#define	FUNC_ENTRY_MODE_SET		0x06		// Entry mode set
#define	FUNC_DISPLAY_ON_OFF		0x0C		// Display ON/OFF control: display on, cursor off, blink off
#define	FUNC_INITIALIZE			0x38		// Function set: 8 bit data, 2 lines
#define	FUNC_CGRAM_WRITE		0x40		// CG RAM write
#define	FUNC_DDRAM_WRITE		0x80		// DD RAM write

// Maximum LCD string length
#define	MAX_LCD_SIZE			12

///////////////////////////////////////////////////////////////////////////////
//
// Piulses the enable bit
//
page2 void lcdPulseEnable(void)
{
	LCD_ENABLE_BIT = 0;
	nop();
	LCD_ENABLE_BIT = 1;
}

///////////////////////////////////////////////////////////////////////////////
//
// Delays for 100 usec
//
page2 void lcdDelay100us(void)
{
	byte i;

	for(i = 0; i < 34; i++);
}

///////////////////////////////////////////////////////////////////////////////
//
// Delays for 2000 usec
//
page2 void lcdDelay2000us(void)
{
	byte i;

	for(i = 0; i < 20; i++) lcdDelay100us();
}

///////////////////////////////////////////////////////////////////////////////
//
// Waits for LCD busy flag to clear
//
page2 void lcdWaitForReady(void)
{
#ifdef TWO_WAY_LCD
	// Configure PORTD to input mode
	RP0 = 1;
	TRISD = 0xFF;
	RP0 = 0;

	// Read from LCD mode
	LCD_RW_BIT = 1;

	// Command
	LCD_RS_BIT = 0;

	// Wait for D7 to clear
	while(PORTD.7);
#endif
}

///////////////////////////////////////////////////////////////////////////////
//
// Sends a byte to the LCD
//
page2 void lcdSendByte(byte dataOrCmd)
{
#ifdef TWO_WAY_LCD
	// Write to LCD mode
	LCD_RW_BIT = 0;

	// Configure PORTD to output mode
	RP0 = 1;
	TRISD = 0x00;
	RP0 = 0;

	// Write the byte
	PORTD = dataOrCmd;

	// Generate enable pulse
	lcdPulseEnable();
#else
	// Write the byte
	PORTD = dataOrCmd;

	// Wait a bit
	lcdDelay100us();

	// Generate enable pulse
	lcdPulseEnable();

	// Wait for the command to complete
	lcdDelay2000us();
#endif
}

///////////////////////////////////////////////////////////////////////////////
//
// Sends an LCD command byte
//
page2 void lcdCommand(byte cmdByte)
{
	lcdWaitForReady();

	// Select command
	LCD_RS_BIT = 0;

	lcdSendByte(cmdByte);
}

///////////////////////////////////////////////////////////////////////////////
//
// Sends an LCD data byte
//
page2 void lcdData(byte dataByte)
{
	lcdWaitForReady();

	// Select data
	LCD_RS_BIT = 1;

	lcdSendByte(dataByte);
}

///////////////////////////////////////////////////////////////////////////////
//
// Sends an LCD data byte
//
page2 void lcdInit(void)
{
	byte i;

	// Setup the port directions
	RP0 = 1;
	TRISD = 0x00;	// RD0-7 output
	TRISE = 0x00;	// RE0-2 output
	RP0 = 0;

	// Initialize parallel port output
	PORTD = FUNC_INITIALIZE;
	LCD_ENABLE_BIT = 1;
	LCD_RS_BIT = 0;
	LCD_RW_BIT = 0;

	// Delay 20msec then pulse enable
	for(i = 0; i < 10; i++) lcdDelay2000us();
	lcdPulseEnable();

	// Delay 4.1msec then pulse enable
	for(i = 0; i < 41; i++) lcdDelay100us();
	lcdPulseEnable();

	// Delay 100usec then pulse enable
	lcdDelay100us();
	lcdPulseEnable();

	// Function set
	lcdCommand(FUNC_INITIALIZE);

	// Display on, cursor off, blink off
	lcdCommand(FUNC_DISPLAY_ON_OFF);

	// Clear display
	lcdCommand(FUNC_CLEAR_DISPLAY);

	// Entry mode set
	lcdCommand(FUNC_ENTRY_MODE_SET);

	// Write special characters to CG RAM
	lcdCommand(FUNC_CGRAM_WRITE);

	for(i = 0; i < (8 * 8); i++) lcdData(cgramTable(i));
}

///////////////////////////////////////////////////////////////////////////////
//
// Sends a string to a specific position on the LCD.
//
page2 void lcdSpecific(int y,int x,const char *s)
{
	int i;
	byte b;

	i = y * 40;
	i += x;

	lcdCommand(FUNC_DDRAM_WRITE + i);

	for(i = 0; *s; i++)
	{
		b = (byte)(*s++) & 0x7F;
		lcdData(b);
	}
}

#ifdef JJS

///////////////////////////////////////////////////////////////////////////////
//
// Sends an LCD line
//
page2 void lcdLine(const char *s)
{
	int i;
	byte b;

	for(i = 0; *s; i++)
	{
		b = (byte)(*s++) & 0x7F;
		lcdData(b);
	}

	for(i = i; i < MAX_LCD_SIZE; i++) lcdData((byte)(' '));
}

///////////////////////////////////////////////////////////////////////////////
//
// Sends a pair of LCD strings.  Both lines must be painted every time to
// write any text to the LCD.
//
page2 void lcdPair(const char *top,const char *bottom)
{
	lcdCommand(FUNC_DDRAM_WRITE + 0);
	lcdLine(top);

	lcdCommand(FUNC_DDRAM_WRITE + 40);
	lcdLine(bottom);
}

///////////////////////////////////////////////////////////////////////////////
//
// Classic strcpy()
//
page2 void strcpy(char *dst,const char *src)
{
	char c;

	while(*src)
	{
		c = *src++;
		*dst++ = c;
	}
	*dst = '\0';
}

///////////////////////////////////////////////////////////////////////////////
//
// Classic strncpy()
//
page2 void strncpy(char *dst,const char *src,int n)
{
	char c;

	while(*src)
	{
		c = *src++;
		*dst++ = c;

		n--;
		if(!n) return;
	}
	*dst = '\0';
}

#endif

