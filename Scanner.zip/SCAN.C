/******************************************************************************

	PIC16F870 as a Switch Scanner
	-----------------------------
	Copyright 2004 by John Speth

	There are 6 rows and 8 columns for scanning 48 switches.  The rows are
	driven and the columns are read.

	Row 5 - RB7 - pin 28
	Row 4 - RB6 - pin 27
	Row 3 - RB5 - pin 26
	Row 2 - RB4 - pin 25
	Row 1 - RB3 - pin 24
	Row 0 - RB2 - pin 23

	Col 7 - RC7 - pin 18
	Col 6 - RC6 - pin 17
	Col 5 - RC5 - pin 16
	Col 4 - RC4 - pin 15
	Col 3 - RC3 - pin 14
	Col 2 - RC2 - pin 13
	Col 1 - RC1 - pin 12
	Col 0 - RC0 - pin 11

	MCLRn is used to hard reset the device.

	Demo board connections:
		Test point row:
			1 - GND
			2 - +5V
			3 - LED clock (input)
			4 - LED data (input)
			5 - scanner clock (input)
			6 - scanner data (output)
			7 - MCLRn (input)
			8 - RESETn (input)

		2x5 connector pins:
			1 - GND
			2 - GND
			3 - +5V
			4 - +5V
			5 - LED clock (input)
			6 - LED data (input)
			7 - scanner clock (input)
			8 - scanner data (output)
			9 - MCLRn (input)
			10 - RESETn (input)

		DIP16:
			1  - LED clock (input)
			2  - LED data (input)
			3  - scanner clock (input)
			4  - scanner data (output)
			5  - NC
			6  - NC
			7  - MCLRn (input)
			8  - RESETn (input)
			9  - GND
			10 - GND
			11 - GND
			12 - GND
			13 - +5V
			14 - +5V
			15 - +5V
			16 - +5V

		DIP16:
			1  - NC
			2  - NC
			3  - Row 5 (RB7 - pin 28)
			4  - Row 4 (RB6 - pin 27)
			5  - Row 3 (RB5 - pin 26)
			6  - Row 2 (RB4 - pin 25)
			7  - Row 1 (RB3 - pin 24)
			8  - Row 0 (RB2 - pin 23)
			9  - Col 0 (RC0 - pin 11)
			10 - Col 1 (RC1 - pin 12)
			11 - Col 2 (RC2 - pin 13)
			12 - Col 3 (RC3 - pin 14)
			13 - Col 4 (RC4 - pin 15)
			14 - Col 5 (RC5 - pin 16)
			15 - Col 6 (RC6 - pin 17)
			16 - Col 7 (RC7 - pin 18)

	Row/column schematic:

	   col col col col col col col col
	    7   6   5   4   3   2   1   0

		R	R	R	R	R	R	R	R
		|	|	|	|	|	|	|	|
	----*---*---*---*---*---*---*---*---< RB7	row 5	(misc)
		|	|	|	|	|	|	|	|
	----*---*---*---*---*---*---*---*---< RB6	row 4	(misc)
		|	|	|	|	|	|	|	|
	----*---*---*---*---*---*---*---*---< RB5	row 3	(channel 2 pause)
		|	|	|	|	|	|	|	|
	----*---*---*---*---*---*---*---*---< RB4	row 2	(channel 2 skip)
		|	|	|	|	|	|	|	|
	----*---*---*---*---*---*---*---*---< RB3	row 1	(channel 1 pause)
		|	|	|	|	|	|	|	|
	----*---*---*---*---*---*---*---*---< RB2	row 0	(channel 1 skip)
		|	|	|	|	|	|	|	|
		V	V	V	V	V	V	V	V
	   RC7 RC6 RC5 RC4 RC3 RC2 RC1 RC0

	Rows 0 through 3 do not need to be debounced.  Rows 4 and 5 need to be
	debounced.

	Switch status data may be queried using a synchronous serial method.  It
	is a two wire interface.  48 bit data is transferred in MSB to LSB order.
	A rising edge of the clock pin (RB0 - pin 21) loads the next bit onto the
	data output pin (RA0 - pin 2).  If reset (RB1 - pin 22) is low on a
	rising clock edge, the interface is reset (the interface points to the
	first bit in the packet).  At least 22usec must separate the clock rising
	edges.

******************************************************************************/

#include <16f870.h>
#include <int16cxx.h>

// CPU hardware configuration
#pragma	config |= 0x3FFF
#pragma	config FOSC=HS, WDTE=off, PWRTE=on, BODEN=off
#define	LVP 0x0080
#pragma	config &= ~LVP

// Booleans
#define	TRUE						1
#define	FALSE						0

// Native data definitions
typedef unsigned char byte;
typedef unsigned long word;

// Port bit definitions
#pragma bit DATAOUT_BIT		@ PORTA.0
#pragma bit RESET_BIT		@ PORTB.1
#pragma bit CLOCKIN_BIT		@ PORTB.0

//
// Various macros
//
#define	TIMER_RATE					-38		// TMR0 value to achieve a 250usec rollover
#define	DEBOUNCE_TERMINUS			125		// Defines the debounce integration period
#define	DEBOUNCE_INACTIVE			-127	// Switch debounce inactive code
#define	NUM_SWITCHES				48		// The number of switches
#define	NUM_SWITCH_STATUS_BYTES		6		// The number of switch status storage byte

// Switch alias macros
#define	NOW_R4C0  					gSwitchByte[4].0
#define	NOW_R4C1  					gSwitchByte[4].1
#define	NOW_R4C2  					gSwitchByte[4].2
#define	NOW_R4C3  					gSwitchByte[4].3
#define	NOW_R4C4  					gSwitchByte[4].4
#define	NOW_R4C5  					gSwitchByte[4].5
#define	NOW_R4C6  					gSwitchByte[4].6
#define	NOW_R4C7  					gSwitchByte[4].7
#define	NOW_R5C0 					gSwitchByte[5].0
#define	NOW_R5C1 					gSwitchByte[5].1
#define	NOW_R5C2 					gSwitchByte[5].2
#define	NOW_R5C3 					gSwitchByte[5].3
#define	NOW_R5C4 					gSwitchByte[5].4
#define	NOW_R5C5 					gSwitchByte[5].5
#define	NOW_R5C6 					gSwitchByte[5].6
#define	NOW_R5C7 					gSwitchByte[5].7

#define	LAST_R4C0  					gLastSwitchByte[4].0
#define	LAST_R4C1  					gLastSwitchByte[4].1
#define	LAST_R4C2  					gLastSwitchByte[4].2
#define	LAST_R4C3  					gLastSwitchByte[4].3
#define	LAST_R4C4  					gLastSwitchByte[4].4
#define	LAST_R4C5  					gLastSwitchByte[4].5
#define	LAST_R4C6  					gLastSwitchByte[4].6
#define	LAST_R4C7  					gLastSwitchByte[4].7
#define	LAST_R5C0 					gLastSwitchByte[5].0
#define	LAST_R5C1 					gLastSwitchByte[5].1
#define	LAST_R5C2 					gLastSwitchByte[5].2
#define	LAST_R5C3 					gLastSwitchByte[5].3
#define	LAST_R5C4 					gLastSwitchByte[5].4
#define	LAST_R5C5 					gLastSwitchByte[5].5
#define	LAST_R5C6 					gLastSwitchByte[5].6
#define	LAST_R5C7 					gLastSwitchByte[5].7

#define	FINAL_R4C0  				gFinalSwitchByte[4].0
#define	FINAL_R4C1  				gFinalSwitchByte[4].1
#define	FINAL_R4C2  				gFinalSwitchByte[4].2
#define	FINAL_R4C3  				gFinalSwitchByte[4].3
#define	FINAL_R4C4  				gFinalSwitchByte[4].4
#define	FINAL_R4C5  				gFinalSwitchByte[4].5
#define	FINAL_R4C6  				gFinalSwitchByte[4].6
#define	FINAL_R4C7  				gFinalSwitchByte[4].7
#define	FINAL_R5C0 					gFinalSwitchByte[5].0
#define	FINAL_R5C1 					gFinalSwitchByte[5].1
#define	FINAL_R5C2 					gFinalSwitchByte[5].2
#define	FINAL_R5C3 					gFinalSwitchByte[5].3
#define	FINAL_R5C4 					gFinalSwitchByte[5].4
#define	FINAL_R5C5 					gFinalSwitchByte[5].5
#define	FINAL_R5C6 					gFinalSwitchByte[5].6
#define	FINAL_R5C7 					gFinalSwitchByte[5].7

// Switch status storage
byte gSwitchByte[NUM_SWITCH_STATUS_BYTES];		// Current status
byte gLastSwitchByte[NUM_SWITCH_STATUS_BYTES];	// Previous status
byte gFinalSwitchByte[NUM_SWITCH_STATUS_BYTES];	// Debounced status

// Debounce integrator counts
int gDebounceCount[NUM_SWITCHES];

// Data output indices
byte gOutputIndex;
byte gOutputMask;

///////////////////////////////////////////////////////////////////////////////
//
// Interrupt handler
//
// Worst case run time: 20usec
//
// Adds up to 1msec per 48 bits which includes a comfortable margin
//

#pragma origin 4

interrupt int_server(void)
{
	int_save_registers
	char sv_FSR = FSR;

	if(INTF)
	{
		// Clear the interrupt
		INTF = 0;

		// Check for reset
		if(!RESET_BIT)
		{
			gOutputMask = 0x80;
			gOutputIndex = 0;

			goto leaveISR;
		}

		// Set the data output bit ready for the falling edge of the clock
		if(gFinalSwitchByte[gOutputIndex] & gOutputMask) DATAOUT_BIT = 1;
		else DATAOUT_BIT = 0;

		// Increment the output indices
		gOutputMask >>= 1;
		if(!gOutputMask)
		{
			gOutputMask = 0x80;

			gOutputIndex++;
			if(gOutputIndex == NUM_SWITCH_STATUS_BYTES) gOutputIndex = 0;
		}
	}

leaveISR:
	FSR = sv_FSR;
	int_restore_registers
}

///////////////////////////////////////////////////////////////////////////////
//
// Initializes the switch scanner
//
void initScanner(void)
{
	int i;

	for(i = 0; i < NUM_SWITCH_STATUS_BYTES; i++)
	{
		gSwitchByte[i] = 0xFF;
		gLastSwitchByte[i] = 0xFF;
		gFinalSwitchByte[i] = 0xFF;
	}

	for(i = 0; i < NUM_SWITCHES; i++) gDebounceCount[i] = DEBOUNCE_INACTIVE;
}

///////////////////////////////////////////////////////////////////////////////
//
// Runs the scanner state machine
//
int scannerFSM(int state)
{
	#define	DRIVE_ROW(mask)		RP0 = 1; TRISB = ~mask; RP0 = 0

	switch(state)
	{
		case 0:
			DRIVE_ROW(0x04);				// Drive row 0
			return 1;

		case 1:
			gFinalSwitchByte[0] = PORTC;	// Read columns from driven row 0
			DRIVE_ROW(0x08);				// Drive row 1
			return 2;

		case 2:
			gFinalSwitchByte[1] = PORTC;	// Read columns from driven row 1
			DRIVE_ROW(0x10);				// Drive row 2
			return 3;

		case 3:
			gFinalSwitchByte[2] = PORTC;	// Read columns from driven row 2
			DRIVE_ROW(0x20);				// Drive row 3
			return 4;

		case 4:
			gFinalSwitchByte[3] = PORTC;	// Read columns from driven row 3
			DRIVE_ROW(0x40);				// Drive row 4
			return 5;

		case 5:
			gSwitchByte[4] = PORTC;			// Read columns from driven row 4
			DRIVE_ROW(0x80);				// Drive row 5
			return 6;

		case 6:
			gSwitchByte[5] = PORTC;			// Read columns from driven row 5
			DRIVE_ROW(0x04);				// Drive row 0
			return 1;
	}

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Debounces the switches
//
void debounce(void)
{
	// The debounce macro
	#define	DEBOUNCE(now,last,final,index) \
		if(now != last) gDebounceCount[index] = 0; \
		if(gDebounceCount[index] != DEBOUNCE_INACTIVE) \
		{ \
			if(now) gDebounceCount[index]++; \
			else gDebounceCount[index]--; \
		} \
		if((gDebounceCount[index] == DEBOUNCE_TERMINUS) || (gDebounceCount[index] == -DEBOUNCE_TERMINUS)) \
		{ \
			final = now; \
			gDebounceCount[index] = DEBOUNCE_INACTIVE; \
		} \
		last = now

	// Debounce the required switches
	DEBOUNCE(NOW_R4C0,LAST_R4C0,FINAL_R4C0,32);
	DEBOUNCE(NOW_R4C1,LAST_R4C1,FINAL_R4C1,33);
	DEBOUNCE(NOW_R4C2,LAST_R4C2,FINAL_R4C2,34);
	DEBOUNCE(NOW_R4C3,LAST_R4C3,FINAL_R4C3,35);
	DEBOUNCE(NOW_R4C4,LAST_R4C4,FINAL_R4C4,36);
	DEBOUNCE(NOW_R4C5,LAST_R4C5,FINAL_R4C5,37);
	DEBOUNCE(NOW_R4C6,LAST_R4C6,FINAL_R4C6,38);
	DEBOUNCE(NOW_R4C7,LAST_R4C7,FINAL_R4C7,39);
	DEBOUNCE(NOW_R5C0,LAST_R5C0,FINAL_R5C0,40);
	DEBOUNCE(NOW_R5C1,LAST_R5C1,FINAL_R5C1,41);
	DEBOUNCE(NOW_R5C2,LAST_R5C2,FINAL_R5C2,42);
	DEBOUNCE(NOW_R5C3,LAST_R5C3,FINAL_R5C3,43);
	DEBOUNCE(NOW_R5C4,LAST_R5C4,FINAL_R5C4,44);
	DEBOUNCE(NOW_R5C5,LAST_R5C5,FINAL_R5C5,45);
	DEBOUNCE(NOW_R5C6,LAST_R5C6,FINAL_R5C6,46);
	DEBOUNCE(NOW_R5C7,LAST_R5C7,FINAL_R5C7,47);
}

///////////////////////////////////////////////////////////////////////////////
//
// Program starts here
//
void main(void)
{
	int state;

	// Setup the port directions
	RP0 = 1;
	ADCON1 = 0x06;	// Make all analog pins digital
	TRISA = 0x00;	// RA0-5 output
	TRISB = 0xFF;	// RB0-7 input
	TRISC = 0xFF;	// RC0-7 input
	RP0 = 0;

	// Initialize the scanner ports
	PORTA = 0x00;
	PORTB = 0x00;

	// Initialize the working RAM
	initScanner();

	state = 0;

	gOutputIndex = 0;
	gOutputMask = 0x80;

	// PortB pullups, RB0 interrupt on the rising edge, prescale /16
	RP0 = 1;
	OPTION = 0x43;
	RP0 = 0;

	// Set the timer rate
	TMR0 = TIMER_RATE;

	// Enable RB0 interrupt
	INTE = 1;
	GIE = 1;

	for(;;)
	{
		// Handle scanning through the timer
		if(T0IF)
		{
			// Restart the timer
			TMR0 = TIMER_RATE;
			T0IF = 0;

			state = scannerFSM(state);

			debounce();
		}
	}
}

