/****************************************************************************

    Dual Quantizer Design - Copyright 2001-2002 - John J Speth

    Uses:
        MP7542 12 bit DAC
        PIC16F84 @ 10MHz

    Port assignment:
        RA0:3   DAC data bus
        RA4     Channel 1 comparator input
        RB0/INT DAC WR strobe
        RB1:2   DAC nibble select bus
        RB3     Channel 2 comparator input
        RB4     Channel 2 12/1 quantize input
        RB5     Channel 1 12/1 quantize input
        RB6     Channel 1 sample strobe (also J1 calibration input)
        RB7     Channel 2 sample strobe (also J2 calibration input)

****************************************************************************/

//#define DAC_TEST

#include <16f84.h>

// CPU hardware configuration
#pragma config |= 0x3FFF
#pragma config FOSC=HS, WDTE=off, PWRTE=on

// Standard boolean definitions
#define TRUE                1
#define FALSE               0

// Sample strobe time (>100us)
#define SAMPLE_TIME         16

// DAC voltage constants
#define DAC_NEG_10_VOLTS    0x08
#define DAC_0_VOLTS         0x80
#define DAC_POS_10_VOLTS    0xF8

// Native data definitions
typedef unsigned char byte;
typedef unsigned long word;

// I/0 bit definitions
#pragma bit DAC_D0      @ PORTA.0   // O: DAC data 0
#pragma bit DAC_D1      @ PORTA.1   // O: DAC data 1
#pragma bit DAC_D2      @ PORTA.2   // O: DAC data 2
#pragma bit DAC_D3      @ PORTA.3   // O: DAC data 3
#pragma bit COMPARE1    @ PORTA.4   // I: Channel 1 Comparator - 0=DAC>CV, 1=DAC<CV

#pragma bit DAC_WR      @ PORTB.0   // O: DAC WR
#pragma bit DAC_A0      @ PORTB.1   // O: DAC nibble select 0
#pragma bit DAC_A1      @ PORTB.2   // O: DAC nibble select 1
#pragma bit COMPARE2    @ PORTB.3   // I: Channel 2 comparator - 0=DAC>CV, 1=DAC<CV
#pragma bit SEMITONE2   @ PORTB.4   // I: Channel 2 12/1 quantize - 0=octave, 1=semitone
#pragma bit SEMITONE1   @ PORTB.5   // I: Channel 1 12/1 quantize - 0=octave, 1=semitone
#pragma bit SAMPLE1     @ PORTB.6   // O: Channel 1 sample strobe - 0=sample. 1=hold
#pragma bit SAMPLE2     @ PORTB.7   // O: Channel 2 sample strobe - 0=sample. 1=hold
#pragma bit J1          @ PORTB.6   // I: Calibration jumper 1
#pragma bit J2          @ PORTB.7   // I: Calibration jumper 2

/////////////////////////////////////////////////////////////////////////////
//
// Programmed delay
//
void delay(word del)
{
    word d;

    for(d = 0; d < del; d++);
}

/////////////////////////////////////////////////////////////////////////////
//
// Sends an 8 bit value to the DAC
//
void dacOut(byte dac)
{
    byte i;

    // Write MIDDLE nibble
    DAC_A0 = 1;
    DAC_A1 = 0;
    PORTA = dac;
    DAC_WR = 0;
    DAC_WR = 1;

    // Write HIGH nibble
    DAC_A0 = 0;
    DAC_A1 = 1;
    PORTA = swap(dac);
    DAC_WR = 0;
    DAC_WR = 1;

    // Commit data to output
    DAC_A0 = 1;
    DAC_A1 = 1;
    DAC_WR = 0;
    DAC_WR = 1;

    // Wait for output to settle (>2us)
    for(i = 0; i < 10; i++);
}

//
// Macro for channel quantization.
//
// Step 1: initialize data
// Step 2: binary search
// Step 3: optional octave/semitone quantization
// Step 4: final DAC output
// Step 5: sample to sample/hold
//
#define QUANTIZE(semitone,compare,strobe) \
    dac = 0; \
    mask = 0x80; \
\
    for(i = 0; i < 8; i++)\
    {\
        dac |= mask;\
        dacOut(dac);\
        if(!compare) dac &= ~mask;\
        mask >>= 1;\
    }\
\
    if(!semitone)\
    {\
        rem = dac % 12;\
        dac -= rem;\
    }\
\
    dacOut(dac);\
\
    strobe = 0;\
    delay(SAMPLE_TIME);\
    strobe = 1;

/////////////////////////////////////////////////////////////////////////////
//
// Program starts here
//
void main(void)
{
    byte i;
    byte mask;
    byte dac;
    byte rem;

    RP0 = 1;                // Select bank 1
    OPTION = 0b00000000;    // Port B pull ups
    TRISA = 0b10000;        // Port A data direction (0=output, 1=input)
    TRISB = 0b11111000;     // Port B data direction (0=output, 1=input)
    RP0 = 0;                // Select bank 0

    // Initialize both ports
    PORTA = 0b00000000;
    PORTB = 0b00000000;

    // Interrupts off
    INTCON = 0;

    // Set DAC low nibble to zero
    DAC_WR = 1;

    // Look for calibration jumpers
    for(;;)
    {
        if(!J1 && !J2) dacOut(DAC_NEG_10_VOLTS);        // -10V on Ch1 and Ch2
        else if(J1 && !J2) dacOut(DAC_0_VOLTS);         // 0V on Ch2
        else if(!J1 && J2) dacOut(DAC_POS_10_VOLTS);    // +10V on Ch1
        else break;
    }

    RP0 = 1;                // Select bank 1
    TRISB = 0b00111000;     // Port B data direction (0=output, 1=input)
    RP0 = 0;                // Select bank 0

    // Initialize both ports
    PORTA = 0b00000000;
    PORTB = 0b11000000;

#ifdef DAC_TEST
    for(;;)
    {
        SAMPLE1 = 1;    SAMPLE2 = 1;
        SAMPLE1 = 0;    SAMPLE2 = 0;
        SAMPLE1 = 1;    SAMPLE2 = 1;

        dacOut(0x00);
        dacOut(0x01);
        dacOut(0x02);
        dacOut(0x04);
        dacOut(0x08);
        dacOut(0x10);
        dacOut(0x20);
        dacOut(0x40);
        dacOut(0x80);
        dacOut(0xFF);
    }
#endif

    for(;;)
    {
        // Quantize channel 1
        QUANTIZE(SEMITONE1,COMPARE1,SAMPLE1);

        // Quantize channel 2
        QUANTIZE(SEMITONE2,COMPARE2,SAMPLE2);
    }
}

